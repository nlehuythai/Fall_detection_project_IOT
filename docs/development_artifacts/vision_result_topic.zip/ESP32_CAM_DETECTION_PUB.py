"""
Camera Object Detection with MQTT Publisher
Detects objects using YOLOv11 and publishes results via MQTT
Specifically designed for fall detection system
"""

import cv2
import json
import paho.mqtt.client as mqtt
from ultralytics import YOLO

# ==================== MQTT CONFIGURATION ====================
MQTT_BROKER = "test.mosquitto.org"
MQTT_PORT = 1883
MQTT_TOPIC = "esp32/camera/detection"
MQTT_CLIENT_ID = "Camera_Publisher"

# ==================== MODEL CONFIGURATION ====================
# Update this path to your YOLOv11 model location
MODEL_PATH = r"/home/yanjiun68/Downloads/UPM EE Y2S1/mini project/13_1_2026_pt_trained_files/best(1).pt"

# ==================== GLOBAL MQTT CLIENT ====================
mqtt_client = None


def setup_mqtt():
    """Initialize and connect to MQTT broker"""
    global mqtt_client
    
    # Create MQTT client instance
    mqtt_client = mqtt.Client(client_id=MQTT_CLIENT_ID)
    
    # Set up callbacks
    mqtt_client.on_connect = on_mqtt_connect
    mqtt_client.on_disconnect = on_mqtt_disconnect
    
    try:
        # Connect to MQTT broker
        print(f"Connecting to MQTT broker at {MQTT_BROKER}:{MQTT_PORT}...")
        mqtt_client.connect(MQTT_BROKER, MQTT_PORT, 60)
        
        # Start network loop in background
        mqtt_client.loop_start()
        
        return mqtt_client
    except Exception as e:
        print(f"✗ Failed to connect to MQTT broker: {e}")
        return None


def on_mqtt_connect(client, userdata, flags, rc):
    """Callback when MQTT client connects to broker"""
    if rc == 0:
        print(f"✓ Connected to MQTT broker successfully")
        print(f"✓ Publishing to topic: {MQTT_TOPIC}")
    else:
        print(f"✗ Connection failed with code {rc}")


def on_mqtt_disconnect(client, userdata, rc):
    """Callback when MQTT client disconnects from broker"""
    if rc != 0:
        print(f"⚠ Unexpected MQTT disconnection. Code: {rc}")


def publish_detection(detections):
    """
    Publish detection results to MQTT broker
    
    Args:
        detections (list): List of detection dictionaries
    """
    global mqtt_client
    
    if mqtt_client is None or not mqtt_client.is_connected():
        print("⚠ MQTT client not connected. Skipping publish.")
        return
    
    try:
        # Convert detections to JSON string
        payload = json.dumps(detections)
        
        # Publish to MQTT topic
        result = mqtt_client.publish(MQTT_TOPIC, payload, qos=1)
        
        # Check if publish was successful
        if result.rc == mqtt.MQTT_ERR_SUCCESS:
            # Only print when objects are detected to reduce console spam
            if len(detections) > 0:
                print(f"✓ Published {len(detections)} detection(s) to MQTT")
        else:
            print(f"✗ Failed to publish to MQTT. Error code: {result.rc}")
            
    except Exception as e:
        print(f"✗ Error publishing to MQTT: {e}")


def load_model(model_path):
    """
    Load the YOLOv11 model from the specified path
    
    Args:
        model_path (str): Path to the YOLO model file (.pt)
    
    Returns:
        YOLO: Loaded YOLO model object
    """
    try:
        print(f"Loading YOLOv11 model from: {model_path}")
        model = YOLO(model_path)
        print("✓ Model loaded successfully")
        return model
    except Exception as e:
        print(f"✗ Error loading model: {e}")
        exit(1)


def camera():
    """
    Open the webcam stream from HTTP server and return the VideoCapture object
    
    Returns:
        cv2.VideoCapture: OpenCV video capture object
    """
    # Connect to HTTP webcam server
    stream_url = "http://10.45.69.52:81/stream"
    cap = cv2.VideoCapture(stream_url)
    
    if not cap.isOpened():
        print("✗ Error: Could not access the webcam server at http://10.199.121.51")
        exit(1)
    
    print("✓ Webcam server opened successfully from http://10.199.121.51")
    return cap


def read_bounding_boxes(detections, frame_shape):
    """
    Read and process bounding-box messages generated during YOLO detection
    Creates detailed parsed data for each detected object

    Args:
        detections (list): Detection messages from YOLO
        frame_shape (tuple): Frame shape (H, W, C)

    Returns:
        list: Parsed bounding box data with pixel coordinates and sizes
    """
    frame_height, frame_width = frame_shape[:2]
    parsed_boxes = []

    for det in detections:
        object_type = det["Object type"]
        x1, y1, x2, y2 = det["Coordinates"]
        confidence = det["Probability"]

        # Calculate bounding box center (in pixels)
        center_x = int((x1 + x2) / 2)
        center_y = int((y1 + y2) / 2)

        # Calculate bounding box size (in pixels)
        box_width = x2 - x1
        box_height = y2 - y1

        # Create parsed box dictionary
        parsed_box = {
            "label": object_type,
            "confidence": confidence,
            "bbox_pixels": {
                "x1": x1,
                "y1": y1,
                "x2": x2,
                "y2": y2
            },
            "center_pixels": {
                "cx": center_x,
                "cy": center_y
            },
            "size_pixels": {
                "width": box_width,
                "height": box_height
            }
        }

        parsed_boxes.append(parsed_box)

    return parsed_boxes 


def object_detection(model, frame):
    """
    Run YOLOv11 inference on the frame and return annotated frame and detection results
    
    Args:
        model (YOLO): Loaded YOLO model
        frame (numpy.ndarray): Input video frame
    
    Returns:
        tuple: (annotated_frame, detections)
            - annotated_frame: Frame with bounding boxes drawn
            - detections: List of detection dictionaries
    """
    # Get the frame dimensions
    image_height, image_width = frame.shape[:2]

    # Run YOLOv11 inference on the frame
    results = model(frame, verbose=False)
    
    # Get annotated frame with bounding boxes
    annotated_frame = results[0].plot()

    # Process detection results
    detections = []
    for box in results[0].boxes:
        # Get class ID and name
        class_id = results[0].names[int(box.cls[0].item())]
        
        # Get bounding box coordinates (top-left and bottom-right)
        x1, y1, x2, y2 = box.xyxy[0].tolist()

        # Calculate box dimensions
        box_width = x2 - x1
        box_height = y2 - y1

        # Calculate normalized center coordinates and dimensions (0-1 range)
        x_center = (x1 + box_width / 2) / image_width
        y_center = (y1 + box_height / 2) / image_height
        width = box_width / image_width
        height = box_height / image_height
        
        # Get confidence score
        conf = round(box.conf[0].item(), 2)

        # Create detection dictionary
        detection = {
            "Object type": class_id,
            "Coordinates": [round(x1), round(y1), round(x2), round(y2)],
            "Probability": conf,
            "X Center": round(x_center, 2),
            "Y Center": round(y_center, 2),
            "Width": round(width, 2),
            "Height": round(height, 2)
        }
        detections.append(detection)

    return annotated_frame, detections


def main():
    """Main function to run the camera detection and MQTT publishing system"""
    print("\n" + "="*60)
    print("YOLOv11 Object Detection with MQTT Publisher")
    print("="*60 + "\n")
    
    # Initialize MQTT connection
    mqtt_client = setup_mqtt()
    if mqtt_client is None:
        print("✗ Cannot proceed without MQTT connection")
        return
    
    # Load the YOLOv11 model
    model = load_model(MODEL_PATH)

    # Open the webcam
    cap = camera()
    
    print("\n" + "="*60)
    print("System Ready - Press 'q' to quit")
    print("="*60 + "\n")

    frame_count = 0
    
    try:
        # Loop through the video frames from the webcam
        while cap.isOpened():
            success, frame = cap.read()
            
            if success:
                frame_count += 1
                
                # Run object detection on the frame
                annotated_frame, detections = object_detection(model, frame)

                # Publish detections to MQTT broker
                publish_detection(detections)
                
                # Create parsed messages for terminal display
                parsed_boxes = read_bounding_boxes(detections, frame.shape)
                
                # Print detection info to console (only when objects detected)
                if len(parsed_boxes) > 0:
                    print(f"\n--- Frame {frame_count} ---")
                    for box in parsed_boxes:
                        print(f"[{box['label']}] "
                              f"Center: ({box['center_pixels']['cx']}, {box['center_pixels']['cy']}) | "
                              f"Size: {box['size_pixels']['width']:.0f}x{box['size_pixels']['height']:.0f} | "
                              f"Conf: {box['confidence']:.2f}")

                # Display the annotated frame in a window
                cv2.imshow("YOLOv11 Inference", annotated_frame)

                # Break the loop if 'q' is pressed
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    print("\n\nShutting down...")
                    break
            else:
                print("✗ Failed to read frame from webcam")
                break
    
    except KeyboardInterrupt:
        print("\n\n⚠ Interrupted by user")
    
    finally:
        # Cleanup resources
        print("\nCleaning up resources...")
        
        # Release the webcam
        cap.release()
        
        # Close display windows
        cv2.destroyAllWindows()
        
        # Disconnect MQTT client
        if mqtt_client is not None:
            mqtt_client.loop_stop()
            mqtt_client.disconnect()
        
        print("✓ System stopped gracefully")
        print("="*60 + "\n")


if __name__ == '__main__':
    main()