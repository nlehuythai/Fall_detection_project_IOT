# PC Host - MQTT Subscriber + Publisher for MPU6050 Fall Detection
# Requires: pip install paho-mqtt

import json
import time
import paho.mqtt.client as mqtt

BROKER = "test.mosquitto.org"
PORT = 1883

TOPIC_MPU_DATA = "esp32/mpu6050/data"
TOPIC_MPU_FALL = "esp32/mpu6050/fall"   # New independent topic

# ===== MPU FALL DETECTION THRESHOLDS =====
GX_THRESHOLD = 1.5
AX_THRESHOLD = 9
AZ_THRESHOLD = 9

COOLDOWN_TIME = 5  # seconds between fall alerts
last_fall_time = 0

# ========================================

def is_fall_condition(data):
    gx = abs(data.get("gx", 0))
    ax = abs(data.get("ax", 0))
    az = abs(data.get("az", 0))

    return gx > GX_THRESHOLD and (ax > AX_THRESHOLD or az > AZ_THRESHOLD)

def on_connect(client, userdata, flags, rc):
    print("✅ Connected with result code", rc)
    client.subscribe(TOPIC_MPU_DATA)

def on_message(client, userdata, msg):
    global last_fall_time

    try:
        data = json.loads(msg.payload.decode())
    except json.JSONDecodeError:
        print("❌ Invalid JSON:", msg.payload)
        return

    print("📡 Received MPU6050 Data:", data)

    # --- FALL DETECTION LOGIC ---
    if is_fall_condition(data):
        now = time.time()

        # Cooldown check to prevent spam
        if now - last_fall_time >= COOLDOWN_TIME:
            last_fall_time = now
            print("🚨 FALL DETECTED by MPU logic!")

            # Publish to independent topic
            alert_msg = json.dumps({
                "event": "MPU_FALL_DETECTED",
                "timestamp": now,
                "data": data
            })

            client.publish(TOPIC_MPU_FALL, alert_msg)
            print(f"📤 Published fall alert to topic: {TOPIC_MPU_FALL}")
        else:
            print("⏳ Fall detected but in cooldown period — ignored.")

# ========================================

client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect(BROKER, PORT, 60)
client.loop_forever()
